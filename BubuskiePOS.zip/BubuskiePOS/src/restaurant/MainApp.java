package restaurant;

import javafx.animation.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainApp {

    private final Stage stage;

    // ── Menu controls ─────────────────────────────────────────────────────────
    private CheckBox cbRiceBeef, cbRiceChicken, cbMacaronBeef, cbFishChips, cbPastaVeg;
    private RadioButton rbCustard, rbChocCake, rbCupcakes, rbIceCream;
    private ComboBox<String> drinksCombo;

    // ── Payment fields ────────────────────────────────────────────────────────
    private TextField tfTotal, tfTendered, tfChange;

    // ── Order summary label ───────────────────────────────────────────────────
    private Label lblOrderCount;

    // ── Prices ────────────────────────────────────────────────────────────────
    private static final double P_RICE_BEEF    = 45.50;
    private static final double P_RICE_CHICKEN = 42.00;
    private static final double P_MACARON_BEEF = 40.00;
    private static final double P_FISH_CHIPS   = 47.50;
    private static final double P_PASTA_VEG    = 38.00;

    private static final double P_CUSTARD  = 30.00;
    private static final double P_CHOC     = 25.00;
    private static final double P_CUPCAKES = 20.00;
    private static final double P_ICECREAM = 18.00;

    // ── Accent colours ────────────────────────────────────────────────────────
    private static final String PURPLE  = "#7c3aed";
    private static final String PINK    = "#db2777";
    private static final String EMERALD = "#10b981";
    private static final String AMBER   = "#f59e0b";
    private static final String RED     = "#ef4444";
    private static final String BLUE    = "#3b82f6";

    public MainApp(Stage stage) { this.stage = stage; }

    // ════════════════════════════════════════════════════════════════════════
    public void show() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #0a0a0f;");

        // Subtle background grid
        Canvas grid = buildGrid(1100, 700);
        StackPane rootWrap = new StackPane(grid, root);
        rootWrap.setStyle("-fx-background-color: #0a0a0f;");

        root.setTop(buildHeader());
        root.setCenter(buildCenter());
        root.setBottom(buildFooter());

        // Fade-in entrance
        root.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(500), root);
        ft.setToValue(1); ft.play();

        Scene scene = new Scene(rootWrap, 1100, 700);
        stage.setTitle("Bubuskie Restaurant  ·  POS");
        stage.setScene(scene);
        stage.setWidth(1100);
        stage.setHeight(700);
        stage.setResizable(false);
        stage.show();
    }

    // ════════════════════════════════════════════════════════════════════════
    // HEADER
    // ════════════════════════════════════════════════════════════════════════
    private Node buildHeader() {
        HBox bar = new HBox();
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(0, 28, 0, 28));
        bar.setPrefHeight(66);
        bar.setStyle(
            "-fx-background-color: rgba(255,255,255,0.035);" +
            "-fx-border-color: rgba(255,255,255,0.08);" +
            "-fx-border-width: 0 0 1 0;"
        );

        // Logo
        StackPane logo = new StackPane();
        Circle logoBg = new Circle(22);
        logoBg.setFill(Color.web(PURPLE, 0.25));
        logoBg.setStroke(Color.web("#a78bfa", 0.4));
        logoBg.setStrokeWidth(1);
        Text logoTxt = new Text("🍽");
        logoTxt.setFont(Font.font(18));
        logo.getChildren().addAll(logoBg, logoTxt);

        VBox brandBox = new VBox(-2);
        brandBox.setPadding(new Insets(0, 0, 0, 12));
        Text name = new Text("NROU'S RESTAURANT");
        name.setFont(Font.font("Georgia", FontWeight.BOLD, 17));
        name.setFill(Color.WHITE);
        Text pos = new Text("Point of Sale System");
        pos.setFont(Font.font("Verdana", 10));
        pos.setFill(Color.web("#6b7280"));
        brandBox.getChildren().addAll(name, pos);

        // Order badge
        lblOrderCount = new Label("0 items");
        lblOrderCount.setFont(Font.font("Verdana", FontWeight.BOLD, 11));
        lblOrderCount.setTextFill(Color.web("#a78bfa"));
        lblOrderCount.setPadding(new Insets(4, 12, 4, 12));
        lblOrderCount.setStyle(
            "-fx-background-color: rgba(124,58,237,0.15);" +
            "-fx-border-color: rgba(124,58,237,0.35);" +
            "-fx-border-radius: 20; -fx-background-radius: 20;"
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Live clock
        Label clock = new Label();
        clock.setFont(Font.font("Courier New", FontWeight.BOLD, 12));
        clock.setTextFill(Color.web("#9ca3af"));
        clock.setAlignment(Pos.CENTER_RIGHT);
        refreshClock(clock);
        Timeline tl = new Timeline(new KeyFrame(Duration.seconds(1), e -> refreshClock(clock)));
        tl.setCycleCount(Animation.INDEFINITE);
        tl.play();

        bar.getChildren().addAll(logo, brandBox, spacer, lblOrderCount, spacer(20), clock);
        return bar;
    }

    private void refreshClock(Label l) {
        l.setText(LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("EEE  dd MMM yyyy    HH:mm:ss")));
    }

    // ════════════════════════════════════════════════════════════════════════
    // CENTER  (3 columns: Dinner | Dessert+Drinks | Payment)
    // ════════════════════════════════════════════════════════════════════════
    private Node buildCenter() {
        HBox cols = new HBox(16);
        cols.setPadding(new Insets(20, 24, 16, 24));
        cols.setFillHeight(true);

        cols.getChildren().addAll(
            buildDinnerPanel(),
            buildDessertDrinksPanel(),
            buildPaymentPanel()
        );
        return cols;
    }

    // ── Dinner panel ──────────────────────────────────────────────────────────
    private Node buildDinnerPanel() {
        VBox panel = card(PURPLE);
        HBox.setHgrow(panel, Priority.ALWAYS);

        panel.getChildren().add(sectionHeader("🍖", "DINNER", "Select one or more", PURPLE));

        cbRiceBeef    = menuCheck("Rice + Beef",            "M" + P_RICE_BEEF,    PURPLE);
        cbRiceChicken = menuCheck("Rice + Chicken",         "M" + P_RICE_CHICKEN, PURPLE);
        cbMacaronBeef = menuCheck("Macaroni + Beef",        "M" + P_MACARON_BEEF, PURPLE);
        cbFishChips   = menuCheck("Fish & Chips",           "M" + P_FISH_CHIPS,   PURPLE);
        cbPastaVeg    = menuCheck("Pasta + Vegetables",     "M" + P_PASTA_VEG,    PURPLE);

        for (CheckBox cb : new CheckBox[]{cbRiceBeef, cbRiceChicken, cbMacaronBeef, cbFishChips, cbPastaVeg}) {
            cb.selectedProperty().addListener((o, ov, nv) -> recalc());
        }

        panel.getChildren().addAll(cbRiceBeef, cbRiceChicken, cbMacaronBeef, cbFishChips, cbPastaVeg);
        return panel;
    }

    // ── Dessert + Drinks panel ────────────────────────────────────────────────
    private Node buildDessertDrinksPanel() {
        VBox col = new VBox(14);
        col.setPrefWidth(320);
        HBox.setHgrow(col, Priority.ALWAYS);

        // Dessert card
        VBox dessert = card(PINK);
        dessert.getChildren().add(sectionHeader("🍰", "DESSERT", "Select one", PINK));

        ToggleGroup tg = new ToggleGroup();
        rbCustard  = menuRadio("Custard and Jelly",     "M" + P_CUSTARD,  tg, PINK);
        rbChocCake = menuRadio("Chocolate Cake Slice",  "M" + P_CHOC,     tg, PINK);
        rbCupcakes = menuRadio("Cupcakes",              "M" + P_CUPCAKES, tg, PINK);
        rbIceCream = menuRadio("Ice Cream",             "M" + P_ICECREAM, tg, PINK);

        for (RadioButton rb : new RadioButton[]{rbCustard, rbChocCake, rbCupcakes, rbIceCream}) {
            rb.selectedProperty().addListener((o, ov, nv) -> recalc());
        }
        dessert.getChildren().addAll(rbCustard, rbChocCake, rbCupcakes, rbIceCream);

        // Drinks card
        VBox drinks = card(BLUE);
        drinks.getChildren().add(sectionHeader("🥤", "DRINKS", "Choose from menu", BLUE));

        drinksCombo = new ComboBox<>();
        drinksCombo.getItems().addAll(
            "None  ·  M0.00",
            "Wine  ·  M55.00",
            "Orange Juice  ·  M22.00",
            "Mineral Water  ·  M10.00",
            "Soda  ·  M18.00",
            "Coffee  ·  M25.00",
            "Beer  ·  M40.00"
        );
        drinksCombo.setValue("None  ·  M0.00");
        drinksCombo.setPrefWidth(Double.MAX_VALUE);
        drinksCombo.setPrefHeight(38);
        drinksCombo.setStyle(
            "-fx-background-color: rgba(59,130,246,0.12);" +
            "-fx-border-color: rgba(59,130,246,0.35);" +
            "-fx-border-radius: 8; -fx-background-radius: 8;" +
            "-fx-text-fill: white; -fx-prompt-text-fill: #9ca3af;"
        );
        drinksCombo.setOnAction(e -> recalc());
        drinks.getChildren().add(drinksCombo);

        col.getChildren().addAll(dessert, drinks);
        VBox.setVgrow(dessert, Priority.ALWAYS);
        return col;
    }

    // ── Payment panel ─────────────────────────────────────────────────────────
    private Node buildPaymentPanel() {
        VBox panel = card(EMERALD);
        panel.setPrefWidth(280);
        panel.getChildren().add(sectionHeader("💳", "PAYMENT", "Enter amount tendered", EMERALD));

        tfTotal    = payField(true,  EMERALD);
        tfTendered = payField(false, EMERALD);
        tfChange   = payField(true,  AMBER);

        tfTendered.textProperty().addListener((o, ov, nv) -> calcChange());

        panel.getChildren().addAll(
            payRow("Total Amount  (M)", tfTotal),
            spacer(6),
            payRow("Amount Tendered  (M)", tfTendered),
            spacer(6),
            payRow("Change  (M)", tfChange)
        );

        // Order breakdown mini-list
        VBox.setVgrow(panel, Priority.ALWAYS);
        return panel;
    }

    // ════════════════════════════════════════════════════════════════════════
    // FOOTER
    // ════════════════════════════════════════════════════════════════════════
    private Node buildFooter() {
        VBox wrap = new VBox(0);

        // Marquee
        Label marquee = new Label(
            "  🍴  WELCOME TO NROU'S RESTAURANT  ·  ENJOY YOUR MEAL  ·  " +
            "FINE DINING SINCE 2024  ·  THANK YOU FOR YOUR PATRONAGE  🍴  ");
        marquee.setFont(Font.font("Verdana", 11));
        marquee.setTextFill(Color.web("#6b7280"));
        marquee.setPadding(new Insets(5, 0, 5, 0));
        marquee.setMaxWidth(Double.MAX_VALUE);
        marquee.setAlignment(Pos.CENTER);
        marquee.setStyle("-fx-background-color: rgba(255,255,255,0.02);");

        // Buttons
        HBox btns = new HBox(12);
        btns.setAlignment(Pos.CENTER);
        btns.setPadding(new Insets(14, 28, 16, 28));
        btns.setStyle(
            "-fx-background-color: rgba(255,255,255,0.03);" +
            "-fx-border-color: rgba(255,255,255,0.07);" +
            "-fx-border-width: 1 0 0 0;"
        );

        Button btnPurchase = footerBtn("🛒   PURCHASE",  EMERALD);
        Button btnChange   = footerBtn("💰   CHANGE",    BLUE);
        Button btnReset    = footerBtn("↺   RESET",      AMBER);
        Button btnExit     = footerBtn("✕   EXIT",       RED);

        btnPurchase.setOnAction(e -> handlePurchase());
        btnChange.setOnAction(e -> calcChange());
        btnReset.setOnAction(e -> handleReset());
        btnExit.setOnAction(e -> handleExit());

        btns.getChildren().addAll(btnPurchase, btnChange, btnReset, btnExit);
        wrap.getChildren().addAll(marquee, btns);
        return wrap;
    }

    // ════════════════════════════════════════════════════════════════════════
    // LOGIC
    // ════════════════════════════════════════════════════════════════════════
    private void recalc() {
        double total = 0;
        int count = 0;

        if (cbRiceBeef.isSelected())    { total += P_RICE_BEEF;    count++; }
        if (cbRiceChicken.isSelected()) { total += P_RICE_CHICKEN; count++; }
        if (cbMacaronBeef.isSelected()) { total += P_MACARON_BEEF; count++; }
        if (cbFishChips.isSelected())   { total += P_FISH_CHIPS;   count++; }
        if (cbPastaVeg.isSelected())    { total += P_PASTA_VEG;    count++; }

        if (rbCustard.isSelected())  { total += P_CUSTARD;  count++; }
        else if (rbChocCake.isSelected()) { total += P_CHOC; count++; }
        else if (rbCupcakes.isSelected()) { total += P_CUPCAKES; count++; }
        else if (rbIceCream.isSelected()) { total += P_ICECREAM; count++; }

        double drink = getDrinkPrice();
        if (drink > 0) { total += drink; count++; }

        tfTotal.setText(String.format("%.2f", total));
        lblOrderCount.setText(count + (count == 1 ? " item" : " items"));
        calcChange();
    }

    private double getDrinkPrice() {
        String v = drinksCombo.getValue();
        if (v == null || v.startsWith("None")) return 0;
        // Extract price after "·  M"
        try {
            int idx = v.lastIndexOf("M");
            return Double.parseDouble(v.substring(idx + 1).trim());
        } catch (Exception e) { return 0; }
    }

    private void calcChange() {
        try {
            double total    = Double.parseDouble(tfTotal.getText().trim());
            double tendered = Double.parseDouble(tfTendered.getText().trim());
            double change   = tendered - total;
            tfChange.setText(String.format("%.2f", change));
            tfChange.setStyle(tfChange.getStyle().replaceAll("-fx-text-fill:[^;]+;",
                "-fx-text-fill: " + (change < 0 ? "#f87171" : "#34d399") + ";"));
        } catch (NumberFormatException ex) {
            tfChange.setText("");
        }
    }

    private void handlePurchase() {
        boolean hasDinner  = cbRiceBeef.isSelected() || cbRiceChicken.isSelected()
                          || cbMacaronBeef.isSelected() || cbFishChips.isSelected()
                          || cbPastaVeg.isSelected();
        boolean hasDessert = rbCustard.isSelected() || rbChocCake.isSelected()
                          || rbCupcakes.isSelected() || rbIceCream.isSelected();

        if (!hasDinner && !hasDessert && getDrinkPrice() == 0) {
            alert(Alert.AlertType.WARNING, "No Items Selected",
                  "Please select at least one menu item before proceeding.");
            return;
        }

        double total, tendered;
        try {
            total    = Double.parseDouble(tfTotal.getText().trim());
            tendered = Double.parseDouble(tfTendered.getText().trim());
        } catch (NumberFormatException e) {
            alert(Alert.AlertType.ERROR, "Input Error",
                  "Please enter a valid numeric value in the Amount Tendered field.");
            return;
        }

        if (tendered < total) {
            alert(Alert.AlertType.ERROR, "Insufficient Funds",
                  "Amount tendered is less than the total.\nPlease check your balance.");
            return;
        }

        String receipt = buildReceipt(total, tendered, tendered - total);
        ReceiptWriter.save(receipt);

        alert(Alert.AlertType.INFORMATION, "Purchase Successful  ✓",
              "Receipt saved to receipts.txt\n\nChange: M" +
              String.format("%.2f", tendered - total) +
              "\n\nThank you for dining at Bubuskie Restaurant! 🍽");
    }

    private String buildReceipt(double total, double tendered, double change) {
        String time = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm:ss"));
        StringBuilder sb = new StringBuilder();
        sb.append("╔══════════════════════════════════════════╗\n");
        sb.append("║        NROU'SRESTAURANT               ║\n");
        sb.append("║           RECEIPT / INVOICE              ║\n");
        sb.append("╠══════════════════════════════════════════╣\n");
        sb.append("  Date & Time : ").append(time).append("\n");
        sb.append("──────────────────────────────────────────\n");
        sb.append("  DINNER:\n");
        if (cbRiceBeef.isSelected())    sb.append("    Rice + Beef              M").append(String.format("%.2f", P_RICE_BEEF)).append("\n");
        if (cbRiceChicken.isSelected()) sb.append("    Rice + Chicken           M").append(String.format("%.2f", P_RICE_CHICKEN)).append("\n");
        if (cbMacaronBeef.isSelected()) sb.append("    Macaroni + Beef          M").append(String.format("%.2f", P_MACARON_BEEF)).append("\n");
        if (cbFishChips.isSelected())   sb.append("    Fish & Chips             M").append(String.format("%.2f", P_FISH_CHIPS)).append("\n");
        if (cbPastaVeg.isSelected())    sb.append("    Pasta + Vegetables       M").append(String.format("%.2f", P_PASTA_VEG)).append("\n");
        sb.append("  DESSERT:\n");
        if (rbCustard.isSelected())  sb.append("    Custard and Jelly        M").append(String.format("%.2f", P_CUSTARD)).append("\n");
        if (rbChocCake.isSelected()) sb.append("    Chocolate Cake           M").append(String.format("%.2f", P_CHOC)).append("\n");
        if (rbCupcakes.isSelected()) sb.append("    Cupcakes                 M").append(String.format("%.2f", P_CUPCAKES)).append("\n");
        if (rbIceCream.isSelected()) sb.append("    Ice Cream                M").append(String.format("%.2f", P_ICECREAM)).append("\n");
        sb.append("  DRINKS:\n");
        String drink = drinksCombo.getValue();
        if (drink != null && !drink.startsWith("None"))
            sb.append("    ").append(drink).append("\n");
        sb.append("──────────────────────────────────────────\n");
        sb.append(String.format("  TOTAL AMOUNT    :  M%.2f%n", total));
        sb.append(String.format("  AMOUNT TENDERED :  M%.2f%n", tendered));
        sb.append(String.format("  CHANGE          :  M%.2f%n", change));
        sb.append("╚══════════════════════════════════════════╝\n");
        sb.append("   YOU ARE WELCOME — ENJOY YOUR FOOD! 🍽\n");
        sb.append("══════════════════════════════════════════\n\n");
        return sb.toString();
    }

    private void handleReset() {
        for (CheckBox cb : new CheckBox[]{cbRiceBeef, cbRiceChicken, cbMacaronBeef, cbFishChips, cbPastaVeg})
            cb.setSelected(false);
        for (RadioButton rb : new RadioButton[]{rbCustard, rbChocCake, rbCupcakes, rbIceCream})
            rb.setSelected(false);
        drinksCombo.setValue("None  ·  M0.00");
        tfTotal.setText(""); tfTendered.setText(""); tfChange.setText("");
        lblOrderCount.setText("0 items");
    }

    private void handleExit() {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle("Exit Application");
        a.setHeaderText("Are you sure you want to exit?");
        a.setContentText("Any unsaved session data will be lost.");
        a.showAndWait().ifPresent(btn -> { if (btn == ButtonType.OK) stage.close(); });
    }

    private void alert(Alert.AlertType t, String header, String msg) {
        Alert a = new Alert(t);
        a.setTitle(header);
        a.setHeaderText(header);
        a.setContentText(msg);
        a.showAndWait();
    }

    // ════════════════════════════════════════════════════════════════════════
    // UI FACTORY
    // ════════════════════════════════════════════════════════════════════════

    private VBox card(String accentHex) {
        VBox v = new VBox(10);
        v.setPadding(new Insets(18, 18, 18, 18));
        v.setStyle(
            "-fx-background-color: rgba(255,255,255,0.04);" +
            "-fx-border-color: rgba(255,255,255,0.08);" +
            "-fx-border-width: 1;" +
            "-fx-border-radius: 14;" +
            "-fx-background-radius: 14;"
        );
        return v;
    }

    private HBox sectionHeader(String icon, String title, String sub, String accentHex) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(0, 0, 8, 0));
        row.setStyle(
            "-fx-border-color: rgba(255,255,255,0.06);" +
            "-fx-border-width: 0 0 1 0;"
        );

        StackPane iconWrap = new StackPane();
        Circle bg = new Circle(16);
        bg.setFill(Color.web(accentHex, 0.2));
        Text ico = new Text(icon);
        ico.setFont(Font.font(13));
        iconWrap.getChildren().addAll(bg, ico);

        VBox titles = new VBox(-2);
        Text t1 = new Text(title);
        t1.setFont(Font.font("Verdana", FontWeight.BOLD, 13));
        t1.setFill(Color.WHITE);
        Text t2 = new Text(sub);
        t2.setFont(Font.font("Verdana", 10));
        t2.setFill(Color.web("#6b7280"));
        titles.getChildren().addAll(t1, t2);

        row.getChildren().addAll(iconWrap, titles);
        return row;
    }

    private CheckBox menuCheck(String label, String price, String accentHex) {
        CheckBox cb = new CheckBox(label);
        cb.setFont(Font.font("Verdana", 12));
        cb.setTextFill(Color.web("#d1d5db"));
        cb.setStyle("-fx-text-fill: #d1d5db;");

        // Add price badge inline via graphic overlay using HBox trick
        HBox row = new HBox(6);
        row.setAlignment(Pos.CENTER_LEFT);
        Label priceLbl = new Label(price);
        priceLbl.setFont(Font.font("Courier New", FontWeight.BOLD, 11));
        priceLbl.setTextFill(Color.web(accentHex));
        priceLbl.setPadding(new Insets(1, 7, 1, 7));
        priceLbl.setStyle(
            "-fx-background-color: rgba(124,58,237,0.15);" +
            "-fx-border-color: rgba(124,58,237,0.3);" +
            "-fx-border-radius: 10; -fx-background-radius: 10;"
        );
        cb.setGraphic(priceLbl);
        cb.setContentDisplay(ContentDisplay.RIGHT);
        return cb;
    }

    private RadioButton menuRadio(String label, String price, ToggleGroup tg, String accentHex) {
        RadioButton rb = new RadioButton(label);
        rb.setToggleGroup(tg);
        rb.setFont(Font.font("Verdana", 12));
        rb.setTextFill(Color.web("#d1d5db"));

        Label priceLbl = new Label(price);
        priceLbl.setFont(Font.font("Courier New", FontWeight.BOLD, 11));
        priceLbl.setTextFill(Color.web(accentHex));
        priceLbl.setPadding(new Insets(1, 7, 1, 7));
        priceLbl.setStyle(
            "-fx-background-color: rgba(219,39,119,0.12);" +
            "-fx-border-color: rgba(219,39,119,0.3);" +
            "-fx-border-radius: 10; -fx-background-radius: 10;"
        );
        rb.setGraphic(priceLbl);
        rb.setContentDisplay(ContentDisplay.RIGHT);
        return rb;
    }

    private TextField payField(boolean readOnly, String accentHex) {
        TextField tf = new TextField();
        tf.setEditable(!readOnly);
        tf.setPrefHeight(36);
        String bg = readOnly ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.07)";
        tf.setStyle(
            "-fx-background-color: " + bg + ";" +
            "-fx-border-color: rgba(255,255,255,0.12);" +
            "-fx-border-radius: 7; -fx-background-radius: 7;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Courier New';" +
            "-fx-font-size: 14;" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 0 10 0 10;"
        );
        if (!readOnly) {
            tf.focusedProperty().addListener((o, ov, nv) -> tf.setStyle(
                "-fx-background-color: rgba(255,255,255,0.09);" +
                "-fx-border-color: " + (nv ? "#10b981" : "rgba(255,255,255,0.12)") + ";" +
                "-fx-border-radius: 7; -fx-background-radius: 7;" +
                "-fx-text-fill: white; -fx-font-family: 'Courier New';" +
                "-fx-font-size: 14; -fx-font-weight: bold; -fx-padding: 0 10 0 10;"
            ));
        }
        return tf;
    }

    private VBox payRow(String labelText, TextField field) {
        VBox group = new VBox(5);
        Label lbl = new Label(labelText);
        lbl.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
        lbl.setTextFill(Color.web("#9ca3af"));
        group.getChildren().addAll(lbl, field);
        return group;
    }

    private Button footerBtn(String text, String colorHex) {
        Button btn = new Button(text);
        btn.setPrefWidth(200);
        btn.setPrefHeight(42);
        btn.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
        btn.setStyle(
            "-fx-background-color: rgba(255,255,255,0.05);" +
            "-fx-border-color: " + colorHex + ";" +
            "-fx-border-width: 1;" +
            "-fx-border-radius: 10; -fx-background-radius: 10;" +
            "-fx-text-fill: " + colorHex + ";" +
            "-fx-cursor: hand;"
        );
        btn.setEffect(new DropShadow(8, Color.web(colorHex, 0.25)));
        btn.setOnMouseEntered(e -> {
            btn.setStyle(
                "-fx-background-color: " + colorHex + ";" +
                "-fx-border-color: " + colorHex + ";" +
                "-fx-border-width: 1;" +
                "-fx-border-radius: 10; -fx-background-radius: 10;" +
                "-fx-text-fill: white; -fx-cursor: hand;"
            );
        });
        btn.setOnMouseExited(e -> {
            btn.setStyle(
                "-fx-background-color: rgba(255,255,255,0.05);" +
                "-fx-border-color: " + colorHex + ";" +
                "-fx-border-width: 1;" +
                "-fx-border-radius: 10; -fx-background-radius: 10;" +
                "-fx-text-fill: " + colorHex + "; -fx-cursor: hand;"
            );
        });
        return btn;
    }

    private Canvas buildGrid(double w, double h) {
        Canvas c = new Canvas(w, h);
        GraphicsContext gc = c.getGraphicsContext2D();
        gc.setStroke(Color.web("#ffffff", 0.025));
        gc.setLineWidth(0.5);
        for (double x = 0; x < w; x += 50) gc.strokeLine(x, 0, x, h);
        for (double y = 0; y < h; y += 50) gc.strokeLine(0, y, w, y);
        return c;
    }

    private Region spacer(double h) {
        Region r = new Region();
        r.setMinHeight(h); r.setPrefHeight(h);
        return r;
    }
}
