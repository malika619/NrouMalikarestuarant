package restaurant;

import javafx.animation.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.stage.*;
import javafx.util.Duration;

public class LoginScreen {

    private final Stage stage;

    public LoginScreen(Stage stage) {
        this.stage = stage;
    }

    public void show() {

        // ── Root: dark radial background ────────────────────────────────────
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: #0a0a0f;");

        // Ambient blobs (decorative circles with blur)
        root.getChildren().addAll(
            blob(260, "#7c3aed", 0.18, -280, -180),
            blob(200, "#db2777", 0.14,  260,  160),
            blob(180, "#0ea5e9", 0.12, -200,  200),
            blob(150, "#f59e0b", 0.10,  280, -150)
        );

        // Subtle grid texture
        Canvas grid = buildGrid(900, 600);
        root.getChildren().add(grid);

        // ── Glass card ───────────────────────────────────────────────────────
        VBox card = new VBox(0);
        card.setAlignment(Pos.TOP_CENTER);
        card.setMaxWidth(400);
        card.setMaxHeight(520);
        card.setStyle(
            "-fx-background-color: rgba(255,255,255,0.05);" +
            "-fx-border-color: rgba(255,255,255,0.12);" +
            "-fx-border-width: 1;" +
            "-fx-border-radius: 24;" +
            "-fx-background-radius: 24;"
        );
        card.setEffect(new DropShadow(60, Color.web("#7c3aed", 0.3)));

        // ── Card header strip ─────────────────────────────────────────────────
        VBox header = new VBox(6);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(36, 40, 28, 40));
        header.setStyle(
            "-fx-background-color: linear-gradient(to bottom, rgba(124,58,237,0.25), transparent);" +
            "-fx-background-radius: 24 24 0 0;"
        );

        // Logo circle
        StackPane logoWrap = new StackPane();
        Circle logoBg = new Circle(32);
        logoBg.setFill(Color.web("#7c3aed", 0.3));
        logoBg.setStroke(Color.web("#a78bfa", 0.5));
        logoBg.setStrokeWidth(1.5);
        Text logoIcon = new Text("🍽");
        logoIcon.setFont(Font.font(28));
        logoWrap.getChildren().addAll(logoBg, logoIcon);
        logoWrap.setEffect(new DropShadow(20, Color.web("#a78bfa", 0.6)));

        // Pulse animation on logo
        ScaleTransition pulse = new ScaleTransition(Duration.seconds(2), logoWrap);
        pulse.setFromX(1.0); pulse.setToX(1.08);
        pulse.setFromY(1.0); pulse.setToY(1.08);
        pulse.setAutoReverse(true);
        pulse.setCycleCount(Animation.INDEFINITE);
        pulse.play();

        Text brandName = new Text("BUBUSKIE");
        brandName.setFont(Font.font("Georgia", FontWeight.BOLD, 28));
        brandName.setFill(Color.WHITE);

        Text brandSub = new Text("RESTAURANT");
        brandSub.setFont(Font.font("Georgia", FontWeight.LIGHT, 13));
        brandSub.setFill(Color.web("#a78bfa"));
        brandSub.setLetterSpacing(6);

        Text welcomeText = new Text("Welcome back");
        welcomeText.setFont(Font.font("Georgia", FontPosture.ITALIC, 12));
        welcomeText.setFill(Color.web("#6b7280"));

        header.getChildren().addAll(logoWrap, brandName, brandSub, welcomeText);

        // ── Form body ─────────────────────────────────────────────────────────
        VBox form = new VBox(14);
        form.setPadding(new Insets(10, 36, 36, 36));
        form.setAlignment(Pos.CENTER);

        // Username
        VBox userGroup = inputGroup("👤  Username", false);
        TextField userField = (TextField) ((VBox) userGroup).getChildren().get(1);

        // Password
        VBox passGroup = inputGroup("🔒  Password", true);
        PasswordField passField = (PasswordField) ((VBox) passGroup).getChildren().get(1);

        // Error label
        Label errLabel = new Label();
        errLabel.setFont(Font.font("Verdana", 11));
        errLabel.setTextFill(Color.web("#f87171"));
        errLabel.setMinHeight(16);

        // Login button
        Button loginBtn = new Button("SIGN IN  →");
        loginBtn.setPrefWidth(Double.MAX_VALUE);
        loginBtn.setPrefHeight(44);
        loginBtn.setFont(Font.font("Verdana", FontWeight.BOLD, 13));
        loginBtn.setStyle(
            "-fx-background-color: linear-gradient(to right, #7c3aed, #db2777);" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 10;" +
            "-fx-cursor: hand;" +
            "-fx-letter-spacing: 2;"
        );
        loginBtn.setEffect(new DropShadow(15, Color.web("#7c3aed", 0.5)));
        loginBtn.setOnMouseEntered(e -> {
            loginBtn.setStyle(
                "-fx-background-color: linear-gradient(to right, #6d28d9, #be185d);" +
                "-fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
            loginBtn.setScaleX(1.02); loginBtn.setScaleY(1.02);
        });
        loginBtn.setOnMouseExited(e -> {
            loginBtn.setStyle(
                "-fx-background-color: linear-gradient(to right, #7c3aed, #db2777);" +
                "-fx-text-fill: white; -fx-background-radius: 10; -fx-cursor: hand;");
            loginBtn.setScaleX(1.0); loginBtn.setScaleY(1.0);
        });

        // Hint
        Label hint = new Label("Demo credentials: admin  /  1234");
        hint.setFont(Font.font("Verdana", 10));
        hint.setTextFill(Color.web("#4b5563"));

        Runnable doLogin = () -> {
            String u = userField.getText().trim();
            String p = passField.getText().trim();
            if (u.isEmpty() || p.isEmpty()) {
                errLabel.setText("⚠  Please fill in all fields.");
                shake(card);
            } else if (u.equals("admin") && p.equals("1234")) {
                FadeTransition ft = new FadeTransition(Duration.millis(400), root);
                ft.setToValue(0);
                ft.setOnFinished(ev -> new MainApp(stage).show());
                ft.play();
            } else {
                errLabel.setText("✖  Invalid credentials. Please try again.");
                shake(card);
            }
        };

        loginBtn.setOnAction(e -> doLogin.run());
        passField.setOnAction(e -> doLogin.run());

        form.getChildren().addAll(userGroup, passGroup, errLabel, loginBtn, hint);
        card.getChildren().addAll(header, form);

        // ── Entrance animation ────────────────────────────────────────────────
        card.setOpacity(0);
        card.setTranslateY(30);
        FadeTransition ft = new FadeTransition(Duration.millis(700), card);
        ft.setToValue(1);
        TranslateTransition tt = new TranslateTransition(Duration.millis(700), card);
        tt.setToY(0);
        tt.setInterpolator(Interpolator.EASE_OUT);
        ParallelTransition pt = new ParallelTransition(ft, tt);
        pt.setDelay(Duration.millis(200));
        pt.play();

        root.getChildren().add(card);

        Scene scene = new Scene(root, 900, 600);
        stage.setTitle("Bubuskie Restaurant");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private VBox inputGroup(String labelText, boolean isPassword) {
        VBox group = new VBox(6);
        Label lbl = new Label(labelText);
        lbl.setFont(Font.font("Verdana", FontWeight.BOLD, 11));
        lbl.setTextFill(Color.web("#9ca3af"));

        TextField field = isPassword ? new PasswordField() : new TextField();
        field.setPrefHeight(40);
        field.setStyle(
            "-fx-background-color: rgba(255,255,255,0.06);" +
            "-fx-border-color: rgba(255,255,255,0.15);" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;" +
            "-fx-text-fill: white;" +
            "-fx-prompt-text-fill: #6b7280;" +
            "-fx-padding: 0 12 0 12;"
        );
        field.focusedProperty().addListener((ob, o, n) -> field.setStyle(
            "-fx-background-color: rgba(255,255,255,0.08);" +
            "-fx-border-color: " + (n ? "#a78bfa" : "rgba(255,255,255,0.15)") + ";" +
            "-fx-border-radius: 8; -fx-background-radius: 8;" +
            "-fx-text-fill: white; -fx-prompt-text-fill: #6b7280;" +
            "-fx-padding: 0 12 0 12;"
        ));
        group.getChildren().addAll(lbl, field);
        return group;
    }

    private Node blob(double r, String color, double opacity, double tx, double ty) {
        Circle c = new Circle(r);
        c.setFill(Color.web(color, opacity));
        c.setTranslateX(tx);
        c.setTranslateY(ty);
        GaussianBlur blur = new GaussianBlur(80);
        c.setEffect(blur);
        return c;
    }

    private Canvas buildGrid(double w, double h) {
        javafx.scene.canvas.Canvas c = new javafx.scene.canvas.Canvas(w, h);
        javafx.scene.canvas.GraphicsContext gc = c.getGraphicsContext2D();
        gc.setStroke(Color.web("#ffffff", 0.03));
        gc.setLineWidth(0.5);
        for (double x = 0; x < w; x += 40) { gc.strokeLine(x, 0, x, h); }
        for (double y = 0; y < h; y += 40) { gc.strokeLine(0, y, w, y); }
        return c;
    }

    private void shake(Node node) {
        TranslateTransition tt = new TranslateTransition(Duration.millis(60), node);
        tt.setByX(8); tt.setAutoReverse(true); tt.setCycleCount(6); tt.play();
    }
}
