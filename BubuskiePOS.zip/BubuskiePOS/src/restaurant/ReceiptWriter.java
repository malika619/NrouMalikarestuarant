package restaurant;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Saves transaction receipts to receipts.txt (opens in Notepad / any text editor).
 * Each transaction is appended so the file accumulates a full transaction log.
 */
public class ReceiptWriter {

    private static final String FILE = "receipts.txt";

    public static void save(String receipt) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE, true))) {
            pw.println(receipt);
            System.out.println("[ReceiptWriter] Saved → " + FILE);
        } catch (IOException e) {
            System.err.println("[ReceiptWriter] ERROR: " + e.getMessage());
        }
    }
}
