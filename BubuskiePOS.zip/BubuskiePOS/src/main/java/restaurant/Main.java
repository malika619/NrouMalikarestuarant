package restaurant;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Debug: Print current directory
            System.out.println("Current working directory: " + System.getProperty("user.dir"));

            // Try different ways to load the FXML
            URL fxmlUrl = getClass().getResource("/restaurant/Welcome.fxml");
            System.out.println("Trying path: /restaurant/Welcome.fxml → " + fxmlUrl);

            if (fxmlUrl == null) {
                // Try without the leading slash
                fxmlUrl = getClass().getResource("restaurant/Welcome.fxml");
                System.out.println("Trying path: restaurant/Welcome.fxml → " + fxmlUrl);
            }

            if (fxmlUrl == null) {
                // Try with class loader
                fxmlUrl = Thread.currentThread().getContextClassLoader().getResource("restaurant/Welcome.fxml");
                System.out.println("Trying ClassLoader: restaurant/Welcome.fxml → " + fxmlUrl);
            }

            if (fxmlUrl == null) {
                System.err.println("❌ ERROR: Could not find Welcome.fxml anywhere!");
                System.err.println("Make sure the file exists at: src/main/resources/restaurant/Welcome.fxml");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Scene scene = new Scene(root, 1200, 800);
            primaryStage.setTitle("BUBUSKIE RESTAURANT - WELCOME");
            primaryStage.setScene(scene);
            primaryStage.show();

            System.out.println("✅ Welcome screen loaded successfully!");

        } catch (Exception e) {
            System.err.println("❌ Error loading welcome screen: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}