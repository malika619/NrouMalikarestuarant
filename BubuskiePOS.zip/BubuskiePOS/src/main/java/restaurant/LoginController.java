package restaurant;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML private StackPane rootPane;
    @FXML private VBox cardPane;
    @FXML private VBox registerPane;

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;
    @FXML private Button showRegisterButton;
    @FXML private Button exitButton;

    @FXML private TextField regUsernameField;
    @FXML private PasswordField regPasswordField;
    @FXML private PasswordField regConfirmPasswordField;
    @FXML private TextField regEmailField;
    @FXML private TextField regPhoneField;
    @FXML private ComboBox<String> regRoleCombo;
    @FXML private Label regErrorLabel;
    @FXML private Button submitRegisterButton;
    @FXML private Button backToLoginButton;

    private Map<String, User> userDatabase = new HashMap<>();
    private static final String USER_FILE = "users.txt";

    // Simple User class
    private static class User {
        String username;
        String password;
        String email;
        String phone;
        String role;

        User(String username, String password, String email, String phone, String role) {
            this.username = username;
            this.password = password;
            this.email = email;
            this.phone = phone;
            this.role = role;
        }

        String toFileString() {
            return username + "|" + password + "|" + email + "|" + phone + "|" + role;
        }

        static User fromFileString(String line) {
            String[] parts = line.split("\\|");
            return new User(parts[0], parts[1], parts[2], parts[3], parts[4]);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Load users from file
        loadUsers();

        // Create default admin if no users exist
        if (userDatabase.isEmpty()) {
            userDatabase.put("admin", new User("admin", "1234", "admin@restaurant.com", "555-0123", "Admin"));
            saveUsers();
            System.out.println("✅ Created default admin user (admin/1234)");
        }

        // Setup role combo box
        if (regRoleCombo != null) {
            regRoleCombo.getItems().addAll("Staff", "Manager", "Admin");
            regRoleCombo.setValue("Staff");
        }

        // Entrance animation
        cardPane.setOpacity(0);
        cardPane.setTranslateY(30);

        FadeTransition ft = new FadeTransition(Duration.millis(700), cardPane);
        ft.setToValue(1);

        TranslateTransition tt = new TranslateTransition(Duration.millis(700), cardPane);
        tt.setToY(0);
        tt.setInterpolator(Interpolator.EASE_OUT);

        ParallelTransition pt = new ParallelTransition(ft, tt);
        pt.setDelay(Duration.millis(150));
        pt.play();

        // Allow Enter key on password field
        passwordField.setOnAction(e -> handleLogin());

        // Initially hide register pane
        if (registerPane != null) {
            registerPane.setVisible(false);
            registerPane.setManaged(false);
        }

        System.out.println("📚 Loaded " + userDatabase.size() + " users");
    }

    // Load users from text file
    private void loadUsers() {
        userDatabase.clear();
        File file = new File(USER_FILE);

        if (!file.exists()) {
            System.out.println("📝 No user file found. Will create default admin.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                try {
                    User user = User.fromFileString(line);
                    userDatabase.put(user.username, user);
                } catch (Exception e) {
                    System.err.println("⚠ Skipping invalid line: " + line);
                }
            }
            System.out.println("✅ Loaded " + userDatabase.size() + " users from " + USER_FILE);
        } catch (IOException e) {
            System.err.println("❌ Error loading users: " + e.getMessage());
        }
    }

    // Save users to text file
    private void saveUsers() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(USER_FILE))) {
            for (User user : userDatabase.values()) {
                writer.println(user.toFileString());
            }
            System.out.println("✅ Saved " + userDatabase.size() + " users to " + USER_FILE);
        } catch (IOException e) {
            System.err.println("❌ Error saving users: " + e.getMessage());
        }
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please fill in all fields.");
            shake(cardPane);
            return;
        }

        User user = userDatabase.get(username);

        if (user != null && user.password.equals(password)) {
            // Successful login
            FadeTransition fade = new FadeTransition(Duration.millis(350), cardPane);
            fade.setToValue(0);
            fade.setOnFinished(e -> loadMainView(user));
            fade.play();
        } else {
            showError("Invalid username or password");
            shake(cardPane);
            passwordField.clear();
        }
    }

    @FXML
    private void showRegister() {
        // Animate transition to register pane
        TranslateTransition slideOut = new TranslateTransition(Duration.millis(300), cardPane);
        slideOut.setToX(-500);
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), cardPane);
        fadeOut.setToValue(0);

        ParallelTransition hideLogin = new ParallelTransition(slideOut, fadeOut);
        hideLogin.setOnFinished(e -> {
            cardPane.setVisible(false);
            cardPane.setManaged(false);
            registerPane.setVisible(true);
            registerPane.setManaged(true);
            registerPane.setOpacity(0);
            registerPane.setTranslateX(500);

            TranslateTransition slideIn = new TranslateTransition(Duration.millis(300), registerPane);
            slideIn.setToX(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(300), registerPane);
            fadeIn.setToValue(1);

            ParallelTransition showRegister = new ParallelTransition(slideIn, fadeIn);
            showRegister.play();

            // Clear any previous error
            regErrorLabel.setText("");
        });
        hideLogin.play();
    }

    @FXML
    private void handleRegister() {
        String username = regUsernameField.getText().trim();
        String password = regPasswordField.getText().trim();
        String confirm = regConfirmPasswordField.getText().trim();
        String email = regEmailField.getText().trim();
        String phone = regPhoneField.getText().trim();
        String role = regRoleCombo.getValue();

        // Validation
        if (username.isEmpty() || password.isEmpty() || confirm.isEmpty() ||
                email.isEmpty() || phone.isEmpty()) {
            regErrorLabel.setText("⚠ All fields are required");
            shake(registerPane);
            return;
        }

        if (username.length() < 3) {
            regErrorLabel.setText("⚠ Username must be at least 3 characters");
            shake(registerPane);
            return;
        }

        if (password.length() < 4) {
            regErrorLabel.setText("⚠ Password must be at least 4 characters");
            shake(registerPane);
            return;
        }

        if (!password.equals(confirm)) {
            regErrorLabel.setText("⚠ Passwords do not match");
            shake(registerPane);
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            regErrorLabel.setText("⚠ Please enter a valid email address");
            shake(registerPane);
            return;
        }

        if (userDatabase.containsKey(username)) {
            regErrorLabel.setText("⚠ Username already exists");
            shake(registerPane);
            return;
        }

        // Create new user
        User newUser = new User(username, password, email, phone, role);
        userDatabase.put(username, newUser);
        saveUsers();

        // Show success message
        regErrorLabel.setText("✅ Registration successful! Please login.");
        regErrorLabel.setStyle("-fx-text-fill: #27ae60; -fx-background-color: #e0ffe0; -fx-border-color: #27ae60;");

        // Clear fields
        regUsernameField.clear();
        regPasswordField.clear();
        regConfirmPasswordField.clear();
        regEmailField.clear();
        regPhoneField.clear();
        regRoleCombo.setValue("Staff");

        // Return to login after 2 seconds
        PauseTransition pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(e -> backToLogin());
        pause.play();
    }

    @FXML
    private void backToLogin() {
        // Animate transition back to login pane
        TranslateTransition slideOut = new TranslateTransition(Duration.millis(300), registerPane);
        slideOut.setToX(500);
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), registerPane);
        fadeOut.setToValue(0);

        ParallelTransition hideRegister = new ParallelTransition(slideOut, fadeOut);
        hideRegister.setOnFinished(e -> {
            registerPane.setVisible(false);
            registerPane.setManaged(false);
            cardPane.setVisible(true);
            cardPane.setManaged(true);
            cardPane.setOpacity(0);
            cardPane.setTranslateX(-500);

            TranslateTransition slideIn = new TranslateTransition(Duration.millis(300), cardPane);
            slideIn.setToX(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(300), cardPane);
            fadeIn.setToValue(1);

            ParallelTransition showLogin = new ParallelTransition(slideIn, fadeIn);
            showLogin.play();

            // Clear fields
            usernameField.clear();
            passwordField.clear();
            errorLabel.setText("");
        });
        hideRegister.play();
    }

    @FXML
    private void handleExit() {
        // Create confirmation dialog
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Exit");
        confirm.setHeaderText("Exit GERTZ Restaurant POS?");
        confirm.setContentText("Are you sure you want to exit the application?");

        // Style the dialog buttons
        DialogPane dialogPane = confirm.getDialogPane();
        dialogPane.setStyle("-fx-background-color: white; -fx-border-color: #e74c3c; -fx-border-width: 2; -fx-border-radius: 10; -fx-background-radius: 10;");

        for (ButtonType buttonType : dialogPane.getButtonTypes()) {
            Button button = (Button) dialogPane.lookupButton(buttonType);
            if (button != null) {
                if (buttonType == ButtonType.OK) {
                    button.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 20; -fx-padding: 8 20; -fx-cursor: hand;");
                } else {
                    button.setStyle("-fx-background-color: #7f8c8d; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 20; -fx-padding: 8 20; -fx-cursor: hand;");
                }
            }
        }

        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                // Exit animation
                ScaleTransition scaleOut = new ScaleTransition(Duration.millis(300), rootPane);
                scaleOut.setToX(0);
                scaleOut.setToY(0);

                FadeTransition fadeOut = new FadeTransition(Duration.millis(300), rootPane);
                fadeOut.setToValue(0);

                ParallelTransition exitTransition = new ParallelTransition(scaleOut, fadeOut);
                exitTransition.setOnFinished(e -> {
                    Platform.exit();
                    System.exit(0);
                });
                exitTransition.play();
            }
        });
    }

    // FIXED: Line 366 - Updated loadMainView method with correct path and error handling
    private void loadMainView(User user) {
        try {
            System.out.println("🔍 Loading MainView.fxml...");

            // Use absolute path from resources
            URL fxmlUrl = getClass().getResource("/restaurant/MainView.fxml");
            System.out.println("FXML URL: " + fxmlUrl);

            if (fxmlUrl == null) {
                System.err.println("❌ ERROR: Could not find MainView.fxml!");
                showError("System error: Main view not found");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            // Get the controller if needed
            Object controller = loader.getController();
            System.out.println("✅ MainController loaded: " + controller);

            // Create scene with proper size
            Scene scene = new Scene(root, 1300, 800);

            // Get current stage
            Stage stage = (Stage) loginButton.getScene().getWindow();

            // Set new scene with smooth transition
            stage.setScene(scene);
            stage.setTitle("GERTZ Restaurant POS - Welcome " + user.username);
            stage.centerOnScreen();

            // Fade in animation for new scene
            root.setOpacity(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), root);
            fadeIn.setToValue(1);
            fadeIn.play();

            System.out.println("✅ Main view loaded successfully");

        } catch (Exception ex) {
            System.err.println("❌ Error loading main view:");
            ex.printStackTrace();
            showError("Could not load main view: " + ex.getMessage());
        }
    }

    private void showError(String msg) {
        errorLabel.setText("⚠ " + msg);
        errorLabel.setManaged(true);
        FadeTransition ft = new FadeTransition(Duration.millis(200), errorLabel);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }

    private void shake(javafx.scene.Node node) {
        TranslateTransition tt = new TranslateTransition(Duration.millis(50), node);
        tt.setByX(6);
        tt.setAutoReverse(true);
        tt.setCycleCount(6);
        tt.play();
    }
}