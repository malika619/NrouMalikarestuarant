package restaurant;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class WelcomeController implements Initializable {

    @FXML private StackPane rootPane;
    @FXML private VBox contentContainer;
    @FXML private Button enterButton;
    @FXML private Button exitButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Simple entrance animation
        contentContainer.setOpacity(0);
        contentContainer.setTranslateY(20);

        FadeTransition fade = new FadeTransition(Duration.seconds(0.8), contentContainer);
        fade.setToValue(1);

        TranslateTransition slide = new TranslateTransition(Duration.seconds(0.8), contentContainer);
        slide.setToY(0);

        ParallelTransition entrance = new ParallelTransition(fade, slide);
        entrance.play();

        // Simple button hover effects
        setupButtonEffects();
    }

    private void setupButtonEffects() {
        enterButton.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), enterButton);
            st.setToX(1.02);
            st.setToY(1.02);
            st.play();
        });

        enterButton.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), enterButton);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        exitButton.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), exitButton);
            st.setToX(1.02);
            st.setToY(1.02);
            st.play();
        });

        exitButton.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), exitButton);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });
    }

    @FXML
    private void goToLogin() {
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.4), rootPane);
        fadeOut.setToValue(0);
        fadeOut.setOnFinished(e -> loadLoginScreen());
        fadeOut.play();
    }

    private void loadLoginScreen() {
        try {
            URL fxmlUrl = getClass().getResource("/restaurant/Login.fxml");
            if (fxmlUrl == null) {
                System.err.println("❌ Could not find Login.fxml");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Scene scene = new Scene(root, 900, 600);
            Stage stage = (Stage) enterButton.getScene().getWindow();

            stage.setScene(scene);
            stage.setTitle("GERTZ'S RESTAURANT - Login");
            stage.centerOnScreen();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void handleExit() {
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.3), rootPane);
        fadeOut.setToValue(0);
        fadeOut.setOnFinished(e -> System.exit(0));
        fadeOut.play();
    }
}