package restaurant;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Appends each transaction receipt to receipts.txt.
 * Open with Notepad (Windows) or any text editor.
 */
public class ReceiptWriter {

    private static final String FILE = "receipts.txt";

    public static void save(String receipt) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE, true))) {
            pw.println(receipt);
            System.out.println("[ReceiptWriter] Saved → " + FILE);
        } catch (IOException e) {
            System.err.println("[ReceiptWriter] ERROR: " + e.getMessage());
        }
    }
}
