package restaurant;

import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    // Dinner CheckBoxes
    @FXML private CheckBox cbRiceBeef;
    @FXML private CheckBox cbRiceChicken;
    @FXML private CheckBox cbMacaronBeef;
    @FXML private CheckBox cbFishChips;
    @FXML private CheckBox cbPastaVeg;

    // Dessert RadioButtons
    @FXML private RadioButton rbCustard;
    @FXML private RadioButton rbChocCake;
    @FXML private RadioButton rbCupcakes;
    @FXML private RadioButton rbIceCream;
    @FXML private ToggleGroup dessertGroup;

    // Drinks ComboBox
    @FXML private ComboBox<String> drinksCombo;

    // Payment fields
    @FXML private TextField tfTendered;
    @FXML private TextField tfChange;

    // Order Summary
    @FXML private TextArea orderSummary;
    @FXML private Label subtotalLabel;
    @FXML private Label discountLabel;
    @FXML private Label totalLabel;
    @FXML private Label lblItemCount;

    // Clock
    @FXML private Label lblClock;

    // Root pane
    @FXML private BorderPane rootPane;

    // Buttons
    @FXML private Button purchaseButton;
    @FXML private Button resetButton;
    @FXML private Button exitButton;

    // Prices
    private static final double P_RICE_BEEF = 45.50;
    private static final double P_RICE_CHICKEN = 42.00;
    private static final double P_MACARON_BEEF = 40.00;
    private static final double P_FISH_CHIPS = 47.50;
    private static final double P_PASTA_VEG = 38.00;
    private static final double P_CUSTARD = 30.00;
    private static final double P_CHOC = 25.00;
    private static final double P_CUPCAKES = 20.00;
    private static final double P_ICECREAM = 18.00;

    // Receipt file
    private static final String RECEIPTS_FILE = "receipts.txt";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialize drinks combo
        drinksCombo.getItems().addAll(
                "None",
                "Wine - M55.00",
                "Orange Juice - M22.00",
                "Mineral Water - M10.00",
                "Soda - M18.00",
                "Coffee - M25.00",
                "Beer - M40.00"
        );
        drinksCombo.setValue("None");

        // Add listeners for all selection controls
        cbRiceBeef.selectedProperty().addListener((obs, old, nv) -> recalc());
        cbRiceChicken.selectedProperty().addListener((obs, old, nv) -> recalc());
        cbMacaronBeef.selectedProperty().addListener((obs, old, nv) -> recalc());
        cbFishChips.selectedProperty().addListener((obs, old, nv) -> recalc());
        cbPastaVeg.selectedProperty().addListener((obs, old, nv) -> recalc());

        rbCustard.selectedProperty().addListener((obs, old, nv) -> recalc());
        rbChocCake.selectedProperty().addListener((obs, old, nv) -> recalc());
        rbCupcakes.selectedProperty().addListener((obs, old, nv) -> recalc());
        rbIceCream.selectedProperty().addListener((obs, old, nv) -> recalc());

        drinksCombo.setOnAction(e -> recalc());
        tfTendered.textProperty().addListener((obs, old, nv) -> calcChange());

        // Start clock
        startClock();

        // Initial calculation
        recalc();

        // Fade in animation
        rootPane.setOpacity(0);
        FadeTransition ft = new FadeTransition(Duration.millis(800), rootPane);
        ft.setToValue(1);
        ft.play();
    }

    private void startClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            lblClock.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        }), new KeyFrame(Duration.seconds(1)));
        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();
    }

    private void recalc() {
        double subtotal = 0;
        int count = 0;
        StringBuilder order = new StringBuilder();

        // Calculate dinners
        if (cbRiceBeef.isSelected()) { subtotal += P_RICE_BEEF; count++; order.append("Rice + Beef: M45.50\n"); }
        if (cbRiceChicken.isSelected()) { subtotal += P_RICE_CHICKEN; count++; order.append("Rice + Chicken: M42.00\n"); }
        if (cbMacaronBeef.isSelected()) { subtotal += P_MACARON_BEEF; count++; order.append("Macaroni + Beef: M40.00\n"); }
        if (cbFishChips.isSelected()) { subtotal += P_FISH_CHIPS; count++; order.append("Fish & Chips: M47.50\n"); }
        if (cbPastaVeg.isSelected()) { subtotal += P_PASTA_VEG; count++; order.append("Pasta + Veg: M38.00\n"); }

        // Calculate desserts
        if (rbCustard.isSelected()) { subtotal += P_CUSTARD; count++; order.append("Custard: M30.00\n"); }
        if (rbChocCake.isSelected()) { subtotal += P_CHOC; count++; order.append("Chocolate Cake: M25.00\n"); }
        if (rbCupcakes.isSelected()) { subtotal += P_CUPCAKES; count++; order.append("Cupcakes: M20.00\n"); }
        if (rbIceCream.isSelected()) { subtotal += P_ICECREAM; count++; order.append("Ice Cream: M18.00\n"); }

        // Calculate drinks
        String drink = drinksCombo.getValue();
        if (drink != null && !drink.equals("None")) {
            double drinkPrice = extractPrice(drink);
            subtotal += drinkPrice;
            count++;
            order.append(drink).append("\n");
        }

        // Update displays
        subtotalLabel.setText(String.format("M%.2f", subtotal));
        totalLabel.setText(String.format("M%.2f", subtotal));
        lblItemCount.setText(count + " item" + (count != 1 ? "s" : ""));
        orderSummary.setText(order.length() > 0 ? order.toString() : "No items selected");

        calcChange();
    }

    private double extractPrice(String drink) {
        try {
            String[] parts = drink.split("M");
            if (parts.length > 1) {
                return Double.parseDouble(parts[1].trim());
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return 0;
    }

    private void calcChange() {
        try {
            double total = Double.parseDouble(totalLabel.getText().replace("M", "").trim());
            double tendered = Double.parseDouble(tfTendered.getText().trim());
            double change = tendered - total;
            tfChange.setText(String.format("%.2f", change));
        } catch (NumberFormatException e) {
            tfChange.setText("0.00");
        }
    }

    @FXML
    private void handlePurchase() {
        // Validate input
        if (tfTendered.getText().trim().isEmpty()) {
            showAlert("Error", "Please enter amount tendered");
            return;
        }

        try {
            double total = Double.parseDouble(totalLabel.getText().replace("M", "").trim());
            double tendered = Double.parseDouble(tfTendered.getText().trim());

            if (tendered < total) {
                showAlert("Insufficient Payment",
                        String.format("Amount tendered (M%.2f) is less than total (M%.2f)", tendered, total));
                return;
            }

            double change = tendered - total;

            // Collect ordered items for receipt
            List<ReceiptItem> items = collectOrderItems();

            // Generate and print receipt
            printReceipt(items, total, tendered, change);

            // Show success message
            showAlert("Purchase Successful",
                    String.format("Payment processed successfully!\nChange: M%.2f\n\nReceipt saved to %s",
                            change, RECEIPTS_FILE));

            // Reset the form
            handleReset();

        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid amount entered");
        }
    }

    // Collect all selected items for receipt
    private List<ReceiptItem> collectOrderItems() {
        List<ReceiptItem> items = new ArrayList<>();

        if (cbRiceBeef.isSelected()) items.add(new ReceiptItem("Rice + Beef", P_RICE_BEEF, 1));
        if (cbRiceChicken.isSelected()) items.add(new ReceiptItem("Rice + Chicken", P_RICE_CHICKEN, 1));
        if (cbMacaronBeef.isSelected()) items.add(new ReceiptItem("Macaroni + Beef", P_MACARON_BEEF, 1));
        if (cbFishChips.isSelected()) items.add(new ReceiptItem("Fish & Chips", P_FISH_CHIPS, 1));
        if (cbPastaVeg.isSelected()) items.add(new ReceiptItem("Pasta + Vegetables", P_PASTA_VEG, 1));

        if (rbCustard.isSelected()) items.add(new ReceiptItem("Custard & Jelly", P_CUSTARD, 1));
        if (rbChocCake.isSelected()) items.add(new ReceiptItem("Chocolate Cake", P_CHOC, 1));
        if (rbCupcakes.isSelected()) items.add(new ReceiptItem("Cupcakes", P_CUPCAKES, 1));
        if (rbIceCream.isSelected()) items.add(new ReceiptItem("Ice Cream", P_ICECREAM, 1));

        String drink = drinksCombo.getValue();
        if (drink != null && !drink.equals("None")) {
            items.add(new ReceiptItem(drink, extractPrice(drink), 1));
        }

        return items;
    }

    @FXML
    private void handleReset() {
        cbRiceBeef.setSelected(false);
        cbRiceChicken.setSelected(false);
        cbMacaronBeef.setSelected(false);
        cbFishChips.setSelected(false);
        cbPastaVeg.setSelected(false);

        dessertGroup.selectToggle(null);

        drinksCombo.setValue("None");
        tfTendered.clear();
        tfChange.clear();

        recalc();
    }

    @FXML
    private void handleExit() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Exit");
        confirm.setHeaderText("Exit Restaurant POS?");
        confirm.setContentText("Are you sure you want to exit?");

        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                Stage stage = (Stage) rootPane.getScene().getWindow();
                stage.close();
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ==================== RECEIPT PRINTING METHODS ====================

    // Inner class for receipt items
    public static class ReceiptItem {
        String name;
        double price;
        int quantity;

        public ReceiptItem(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        public double getTotal() {
            return price * quantity;
        }
    }

    // Main method to print receipt
    private void printReceipt(List<ReceiptItem> items, double total, double tendered, double change) {
        String receipt = generateReceiptString(items, total, tendered, change);

        // Save to file
        saveReceiptToFile(receipt);

        // Show receipt popup
        showReceiptPopup(receipt);
    }

    // Generate receipt text
    private String generateReceiptString(List<ReceiptItem> items, double total, double tendered, double change) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String receiptNo = "RCP" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        StringBuilder sb = new StringBuilder();

        // Header
        sb.append("╔══════════════════════════════════════════════════════════╗\n");
        sb.append("║                 GERTZ RESTAURANT                      ║\n");
        sb.append("║                    FINE DINING & LOUNGE                  ║\n");
        sb.append("╠══════════════════════════════════════════════════════════╣\n");
        sb.append(String.format("║ Receipt No: %-36s ║\n", receiptNo));
        sb.append(String.format("║ Date: %-40s ║\n", timestamp));
        sb.append("╠══════════════════════════════════════════════════════════╣\n");
        sb.append("║ ITEMS:                                                   ║\n");
        sb.append("║----------------------------------------------------------║\n");

        // Items
        for (ReceiptItem item : items) {
            String name = item.name.length() > 25 ? item.name.substring(0, 22) + "..." : item.name;
            sb.append(String.format("║ %-25s M%7.2f x%d %11s ║\n",
                    name, item.price, item.quantity, ""));
        }

        // Totals
        sb.append("╠══════════════════════════════════════════════════════════╣\n");
        sb.append(String.format("║ SUBTOTAL:                                M%7.2f ║\n", total));
        sb.append(String.format("║ TENDERED:                                M%7.2f ║\n", tendered));
        sb.append(String.format("║ CHANGE:                                  M%7.2f ║\n", change));
        sb.append("╠══════════════════════════════════════════════════════════╣\n");
        sb.append("║         THANK YOU FOR DINING WITH US!                   ║\n");
        sb.append("║              PLEASE COME AGAIN                          ║\n");
        sb.append("╚══════════════════════════════════════════════════════════╝\n");
        sb.append("\n");

        return sb.toString();
    }

    // Save receipt to file
    private void saveReceiptToFile(String receipt) {
        try (FileWriter fw = new FileWriter(RECEIPTS_FILE, true);
             PrintWriter writer = new PrintWriter(fw)) {

            writer.println(receipt);
            System.out.println("✅ Receipt saved to " + RECEIPTS_FILE);

        } catch (IOException e) {
            System.err.println("❌ Error saving receipt: " + e.getMessage());
        }
    }

    // Show beautiful receipt popup
    private void showReceiptPopup(String receipt) {
        Stage receiptStage = new Stage();
        receiptStage.initModality(Modality.APPLICATION_MODAL);
        receiptStage.setTitle("🧾 GERTZ RESTAURANT - OFFICIAL RECEIPT");
        receiptStage.setResizable(false);

        // Create receipt display
        TextArea receiptArea = new TextArea(receipt);
        receiptArea.setEditable(false);
        receiptArea.setFont(Font.font("Monospaced", FontWeight.NORMAL, 14));
        receiptArea.setPrefRowCount(25);
        receiptArea.setPrefColumnCount(60);
        receiptArea.setStyle("-fx-control-inner-background: #f8f5e6; -fx-text-fill: #2c3e50;");

        // Close button
        Button closeButton = new Button("✓ CLOSE");
        closeButton.setStyle(
                "-fx-background-color: linear-gradient(to right, #2ecc71, #27ae60);" +
                        "-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;" +
                        "-fx-padding: 12 40; -fx-background-radius: 30; -fx-cursor: hand;"
        );
        closeButton.setOnAction(e -> receiptStage.close());

        // Print button
        Button printButton = new Button("🖨️ PRINT");
        printButton.setStyle(
                "-fx-background-color: linear-gradient(to right, #3498db, #2980b9);" +
                        "-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;" +
                        "-fx-padding: 12 40; -fx-background-radius: 30; -fx-cursor: hand;"
        );
        printButton.setOnAction(e -> {
            showAlert("Print", "Receipt saved to " + RECEIPTS_FILE);
        });

        // Button container
        HBox buttonBox = new HBox(20, closeButton, printButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));

        // Main layout
        BorderPane root = new BorderPane();
        root.setCenter(receiptArea);
        root.setBottom(buttonBox);
        root.setStyle("-fx-background-color: #2c3e50; -fx-padding: 20;");

        // Title
        Label titleLabel = new Label("🧾 OFFICIAL RECEIPT 🧾");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #f1c40f;");
        titleLabel.setPadding(new Insets(0, 0, 10, 0));
        titleLabel.setAlignment(Pos.CENTER);
        BorderPane.setAlignment(titleLabel, Pos.CENTER);
        root.setTop(titleLabel);

        Scene scene = new Scene(root, 750, 650);
        receiptStage.setScene(scene);
        receiptStage.showAndWait();
    }
}