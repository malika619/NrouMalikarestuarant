module restaurant {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;

    opens restaurant to javafx.fxml;
    exports restaurant;
}
